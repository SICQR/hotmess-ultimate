# Brand Notes
Tone: bold, masc, care-first; black/white with an orange flick.
